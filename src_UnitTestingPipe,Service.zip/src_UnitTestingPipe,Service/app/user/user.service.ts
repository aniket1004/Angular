export class UserService 
{
  user = {
            name: 'Piyush Khairnar'
          };
}
