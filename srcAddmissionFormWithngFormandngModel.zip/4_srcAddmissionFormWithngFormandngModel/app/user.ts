export class User 
{
    constructor(
        public sname : string,
        public eaddress : string,
        public mobile : number,
        public payment : string,
        public batch : string,
        public tandc : boolean
    )
    {
    }
}
