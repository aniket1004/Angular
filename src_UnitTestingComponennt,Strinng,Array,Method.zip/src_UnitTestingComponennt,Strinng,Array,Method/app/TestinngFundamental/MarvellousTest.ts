
export function Even(number)
{
    if(number % 2 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}