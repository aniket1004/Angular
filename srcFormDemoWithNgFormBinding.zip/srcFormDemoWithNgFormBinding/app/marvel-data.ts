export class MarvelData 
{
    constructor(public name : string, public feedback : string)
    {

    }
}
