
export function Batches()
{
    return ['PPA','LB','Angular','Python'];
}