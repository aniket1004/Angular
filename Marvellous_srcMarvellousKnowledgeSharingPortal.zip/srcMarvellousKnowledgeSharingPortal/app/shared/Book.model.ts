// Class which holds information of books required for the project

export class Book 
{
  constructor(public name: string, public amount: number) {}
}
