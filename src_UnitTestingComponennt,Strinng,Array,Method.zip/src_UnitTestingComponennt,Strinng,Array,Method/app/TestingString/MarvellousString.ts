
export function Display(student)
{
    return student + ' welcome to Marvellous Infosystems'
}